<?php
$host = 'localhost';
$db = 'sistema_reservas';
$user = 'root';
$pass = ''; // ajuste conforme necessário

$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) {
  die('Erro de conexão: ' . $conn->connect_error);
}

$nome = $_POST['nome'];
$laboratorio_id = $_POST['laboratorio_id'];
$horario_inicio = $_POST['horario_inicio'];
$horario_fim = $_POST['horario_fim'];
$materiais = $_POST['materiais'];
$nota = $_POST['nota'];
$comentario = $_POST['comentario'];

$stmt = $conn->prepare("INSERT INTO reservas (nome_usuario, horario_inicio, horario_fim, laboratorio_id, materiais, nota, comentario) VALUES (?, ?, ?, ?, ?, ?, ?)");
$stmt->bind_param("sssisis", $nome, $horario_inicio, $horario_fim, $laboratorio_id, $materiais, $nota, $comentario);

if ($stmt->execute()) {
  echo "Reserva feita com sucesso!";
} else {
  echo "Erro ao reservar: " . $stmt->error;
}
$conn->close();
?>
