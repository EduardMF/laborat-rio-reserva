
-- Criação do banco de dados
CREATE DATABASE IF NOT EXISTS sistema_reservas;
USE sistema_reservas;

-- Tabela de usuários
CREATE TABLE IF NOT EXISTS usuarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    usuario VARCHAR(50) UNIQUE NOT NULL,
    senha VARCHAR(100) NOT NULL
);

-- Tabela de laboratorios
CREATE TABLE IF NOT EXISTS laboratorios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL
);

-- Tabela de reservas
CREATE TABLE IF NOT EXISTS reservas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome_usuario VARCHAR(100) NOT NULL,
    horario_inicio DATETIME NOT NULL,
    horario_fim DATETIME NOT NULL,
    laboratorio_id INT NOT NULL,
    materiais VARCHAR(255),
    nota INT CHECK (nota >= 1 AND nota <= 5),
    comentario TEXT,
    FOREIGN KEY (laboratorio_id) REFERENCES laboratorios(id)
);

-- Tabela de feedbacks anonimos
CREATE TABLE IF NOT EXISTS feedbacks_anonimos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    comentario TEXT NOT NULL
);

-- Inserindo laboratório de exemplo
INSERT INTO laboratorios (nome) VALUES ('Laboratório 1'), ('Laboratório 2'), ('Laboratório 3');

-- Inserindo usuário admin padrão
INSERT INTO usuarios (nome, usuario, senha) VALUES ('Administrador', 'admin', '1234');
